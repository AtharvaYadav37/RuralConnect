const { GoogleGenerativeAI } = require("@google/generative-ai");

// Make sure to include these imports:
// import { GoogleGenerativeAI } from "@google/generative-ai";
const genAI = new GoogleGenerativeAI("AIzaSyDJp1KSYFMRpPWc_yZxOEHIeh0lVVDxNHQ");
async function run(){
    const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });

    const prompt = "Essay on earth";

    const result = await model.generateContent(prompt);
    console.log(result.response.text());
}
run();