document.getElementById('loginForm').addEventListener('submit', async (event) => {
    event.preventDefault();

    const loginButton = event.target.querySelector('button');
    loginButton.disabled = true;
    loginButton.textContent = 'Logging in...';

    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    try {
        const response = await fetch('/auth/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ username, password })
        });

        // Check if the response is ok (status in the range 200-299)
        if (response.ok) {
            const data = await response.json();
            // Assuming your backend sends a token on successful login
            localStorage.setItem('token', data.token);
            // Redirect to index1.html if login is successful
            window.location.assign("./landingPage/index.html");
        } else {
            const errorData = await response.json(); // Retrieve error message
            alert(errorData.message || 'Login failed'); // Provide feedback
        }

    } catch (error) {
        console.error('Login error:', error); // Log for debugging
        alert(`Error: ${error.message}`);
    } finally {
        loginButton.disabled = false;
        loginButton.textContent = 'Login';
    }
});
